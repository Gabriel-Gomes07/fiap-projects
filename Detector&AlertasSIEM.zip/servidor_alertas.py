# servidor_alertas.py — Módulo 4 (Servidor): Servidor TCP de Alertas
# SecuraPy SIEM
#
# Conceitos da apostila utilizados:
#   Aula 3  — variáveis, f-strings, print()
#   Aula 4  — if/elif/else (tratar comandos do cliente)
#   Aula 6  — while True (loop do servidor aguardando conexões)
#   Aula 7  — dicionários (lista de clientes), listas (histórico de alertas)
#   Aula 8  — try/except (tratar erros de rede e desconexões)
#   Aula 13 — socket TCP, bind, listen, accept, send, recv, threading

import socket
import threading

# ─── Estado global compartilhado entre threads ───────────────────────────────
# Aula 7.3 — dicionário para guardar todos os clientes conectados
clientes = {}

# Aula 7.1 — lista para guardar o histórico dos alertas enviados
historico_alertas = []

# Aula 13 — lock para proteger o dicionário de acesso simultâneo entre threads
lock = threading.Lock()


# ─── Formatar alerta para exibição ───────────────────────────────────────────

def formatar_alerta(alerta):
    """
    Transforma o dicionário de alerta em uma string legível.
    Formato: [HH:MM:SS] [SEVERIDADE] Tipo — IP — Descricao
    """
    # Aula 3 — f-string para montar o texto do alerta
    hora = alerta.get("timestamp", "??:??:??")
    severidade = alerta.get("severidade", "INFO")
    tipo = alerta.get("tipo", "Alerta")
    ip = alerta.get("ip", "desconhecido")
    descricao = alerta.get("descricao", "")

    return f"[{hora}] [{severidade:<8}] {tipo} -- {ip} -- {descricao}"


# ─── Enviar alerta para todos os clientes conectados ─────────────────────────

def broadcast_alerta(alerta):
    """
    Envia um alerta formatado para todos os clientes conectados.
    Clientes que desconectaram são removidos da lista.
    """
    mensagem = formatar_alerta(alerta)

    # Aula 7.1 — guardar no histórico (máximo 50 alertas)
    with lock:
        historico_alertas.append(mensagem)
        if len(historico_alertas) > 50:
            historico_alertas.pop(0)

    # Fazer cópia do dicionário para não travar enquanto itera
    with lock:
        copia_clientes = dict(clientes)

    clientes_para_remover = []

    # Aula 6.3 — percorrer todos os clientes e enviar o alerta
    for conexao in copia_clientes:
        # Aula 8 — try/except para tratar erros de rede
        try:
            conexao.sendall((mensagem + "\n").encode("utf-8"))
        except (ConnectionResetError, BrokenPipeError, OSError):
            clientes_para_remover.append(conexao)

    # Remover clientes que caíram
    with lock:
        for conexao in clientes_para_remover:
            if conexao in clientes:
                del clientes[conexao]

    total = len(copia_clientes) - len(clientes_para_remover)
    print(f"[SERVIDOR] Alerta enviado para {total} cliente(s): {mensagem}")


# ─── Tratar cada cliente em uma thread separada ──────────────────────────────

def tratar_cliente(conexao, endereco):
    """
    Gerencia a comunicação com um cliente individual.
    Esta função roda em uma thread separada para cada cliente.

    Comandos aceitos:
        /status    — mostra clientes conectados e total de alertas
        /historico — exibe os últimos 10 alertas
        /sair      — desconecta o cliente
    """
    # Aula 3 — f-string para montar endereço legível
    endereco_str = f"{endereco[0]}:{endereco[1]}"
    print(f"[SERVIDOR] Cliente conectado: {endereco_str}")

    # Mensagem de boas-vindas ao cliente
    boas_vindas = (
        "\n╔══════════════════════════════════════════╗\n"
        "║   SecuraPy SIEM -- Console de Alertas   ║\n"
        "╚══════════════════════════════════════════╝\n"
        "Comandos: /status | /historico | /sair\n"
        "------------------------------------------\n"
    )

    # Aula 8 — try/except para tratar qualquer erro de conexão
    try:
        conexao.sendall(boas_vindas.encode("utf-8"))

        # Aula 6.4 — while True: fica recebendo mensagens do cliente
        while True:
            # Aula 8 — try/except para capturar desconexão
            try:
                dados = conexao.recv(1024)
            except (ConnectionResetError, OSError):
                break

            # Se recv() retornar vazio, o cliente fechou a conexão
            if not dados:
                break

            # Aula 3 — decodificar bytes para texto
            comando = dados.decode("utf-8").strip().lower()

            # Aula 4 — if/elif/else para tratar cada comando
            if comando == "/sair":
                conexao.sendall("Desconectando. Ate logo!\n".encode("utf-8"))
                break

            elif comando == "/status":
                with lock:
                    qtd_clientes = len(clientes)
                    qtd_alertas = len(historico_alertas)
                resposta = f"\n[STATUS] Clientes: {qtd_clientes} | Alertas registrados: {qtd_alertas}\n"
                conexao.sendall(resposta.encode("utf-8"))

            elif comando == "/historico":
                with lock:
                    # Aula 7.1 — fatiar lista para pegar os últimos 10
                    ultimos = historico_alertas[-10:]

                if len(ultimos) == 0:
                    resposta = "[HISTORICO] Nenhum alerta ainda.\n"
                else:
                    resposta = "\n[HISTORICO - ultimos alertas]\n"
                    for alerta in ultimos:
                        resposta = resposta + alerta + "\n"

                conexao.sendall(resposta.encode("utf-8"))

            else:
                resposta = f"[ERRO] Comando '{comando}' desconhecido. Use: /status | /historico | /sair\n"
                conexao.sendall(resposta.encode("utf-8"))

    except OSError:
        pass   # conexão já foi fechada

    finally:
        # Remover cliente da lista ao desconectar
        with lock:
            if conexao in clientes:
                del clientes[conexao]
        try:
            conexao.close()
        except OSError:
            pass
        print(f"[SERVIDOR] Cliente desconectado: {endereco_str}")


# ─── Iniciar o servidor ───────────────────────────────────────────────────────

def iniciar_servidor(host="0.0.0.0", porta=9999):
    """
    Inicia o servidor TCP e fica aguardando clientes se conectarem.
    Para cada cliente novo, cria uma thread separada.
    """
    # Aula 13.2 — criar socket TCP
    servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Aula 8 — try/except para tratar erros ao iniciar o servidor
    try:
        # Aula 13.2 — bind e listen
        servidor.bind((host, porta))
        servidor.listen(10)

        print("╔══════════════════════════════════════════╗")
        print("║   Servidor de Alertas -- SecuraPy SIEM  ║")
        print("╚══════════════════════════════════════════╝")
        print(f"Rodando em {host}:{porta}")
        print("Aguardando conexoes... (Ctrl+C para parar)\n")

        # Thread para enviar alertas de demonstração automaticamente
        thread_demo = threading.Thread(target=enviar_alertas_demo, daemon=True)
        thread_demo.start()

        # Aula 6.4 — while True: loop principal do servidor
        while True:
            # Aula 8 — try/except para capturar Ctrl+C
            try:
                # Aula 13.2 — accept() espera a próxima conexão
                conexao, endereco = servidor.accept()

                # Aula 7.3 — guardar novo cliente no dicionário
                with lock:
                    clientes[conexao] = f"{endereco[0]}:{endereco[1]}"

                # Aula 13.3 — criar thread para tratar este cliente
                thread = threading.Thread(
                    target=tratar_cliente,
                    args=(conexao, endereco),
                    daemon=True
                )
                thread.start()

            except OSError:
                break

    except KeyboardInterrupt:
        print("\n[SERVIDOR] Encerrando...")

    except OSError as erro:
        print(f"[ERRO] Nao foi possivel iniciar o servidor: {erro}")

    finally:
        # Avisar todos os clientes que o servidor vai fechar
        aviso = "\n[SERVIDOR] Servidor encerrado. Ate logo!\n"
        with lock:
            for conexao in list(clientes.keys()):
                # Aula 8 — try/except para tratar clientes que já caíram
                try:
                    conexao.sendall(aviso.encode("utf-8"))
                    conexao.close()
                except OSError:
                    pass
        servidor.close()
        print("[SERVIDOR] Encerrado com sucesso.")


# ─── Alertas de demonstração (simulam o detector em produção) ─────────────────

def enviar_alertas_demo():
    """
    Aguarda 3 segundos e envia alertas simulados automaticamente.
    Serve para demonstrar o broadcast funcionando na apresentação.
    """
    import time
    time.sleep(3)

    # Aula 7.3 — lista de alertas de demonstração como dicionários
    alertas_demo = [
        {
            "timestamp": "08:15:10",
            "severidade": "CRITICA",
            "tipo": "Brute Force",
            "ip": "185.220.101.1",
            "descricao": "11 tentativas de login falhas detectadas"
        },
        {
            "timestamp": "08:15:11",
            "severidade": "ALTA",
            "tipo": "Port Scan",
            "ip": "185.220.101.1",
            "descricao": "7 portas escaneadas: 21, 22, 23, 139, 445, 3306, 8080"
        },
        {
            "timestamp": "08:15:12",
            "severidade": "CRITICA",
            "tipo": "Blacklist",
            "ip": "185.220.101.1",
            "descricao": "IP encontrado na blacklist de ameacas conhecidas"
        },
        {
            "timestamp": "08:15:13",
            "severidade": "MEDIA",
            "tipo": "Brute Force",
            "ip": "91.240.118.172",
            "descricao": "5 tentativas de login falhas detectadas"
        },
        {
            "timestamp": "08:15:14",
            "severidade": "ALTA",
            "tipo": "Port Scan",
            "ip": "91.240.118.172",
            "descricao": "3 portas escaneadas: 22, 445, 3389"
        },
        {
            "timestamp": "08:15:15",
            "severidade": "ALTA",
            "tipo": "Blacklist",
            "ip": "45.33.32.156",
            "descricao": "IP encontrado na blacklist de ameacas conhecidas"
        }
    ]

    # Aula 6.3 — percorrer e enviar cada alerta com intervalo
    for alerta in alertas_demo:
        with lock:
            if len(clientes) == 0:
                break
        broadcast_alerta(alerta)
        time.sleep(1.5)


# Aula 11.5 — ponto de entrada do módulo
if __name__ == "__main__":
    iniciar_servidor()
