# detector.py — Módulo 3: Detecção de Anomalias e Ataques
# SecuraPy SIEM
#
# Conceitos da apostila utilizados:
#   Aula 4  — if / elif / else (classificar severidade)
#   Aula 6  — for / while (percorrer lista de eventos)
#   Aula 7  — dicionários (contadores por IP), sets (portas únicas, interseção)
#   Aula 8  — try/except (tratar erros inesperados)
#   Aula 10 — funções com parâmetros e retorno

# Blacklist padrão de IPs maliciosos conhecidos
BLACKLIST_PADRAO = {"185.220.101.1", "45.33.32.156", "91.240.118.172", "23.94.5.100"}


# ─── Função auxiliar de severidade ───────────────────────────────────────────

def classificar_severidade(quantidade, threshold_critica, threshold_alta, threshold_media):
    # Aula 4 — if/elif/else para classificar com base em limiares
    if quantidade >= threshold_critica:
        return "CRITICA"
    elif quantidade >= threshold_alta:
        return "ALTA"
    elif quantidade >= threshold_media:
        return "MEDIA"
    else:
        return "BAIXA"


# ─── Função 1: Detecção de Brute Force ───────────────────────────────────────

def detectar_brute_force(eventos, threshold=5):
    """
    Conta tentativas de login com falha (FAIL) por IP.
    Se um IP ultrapassar o threshold, ele é considerado suspeito.

    Retorna um dicionário no formato:
    { "185.220.101.1": {"tentativas": 11, "usuarios": ["admin", "root"], "severidade": "ALTA"} }
    """
    # Aula 7.3 — dicionário para contar falhas por IP
    falhas_por_ip = {}

    # Aula 6.3 — percorrer a lista de eventos com for
    for evento in eventos:
        # Aula 4 — checar fonte e tipo do evento
        if evento["fonte"] == "auth" and evento["tipo"] == "FAIL":
            ip = evento["ip"]
            usuario = evento["detalhes"].replace("usuario=", "")

            # Aula 7.3 — verificar se IP já está no dicionário
            if ip not in falhas_por_ip:
                # Aula 7.5 — set para guardar usuários únicos tentados
                falhas_por_ip[ip] = {"tentativas": 0, "usuarios": set()}

            falhas_por_ip[ip]["tentativas"] += 1
            falhas_por_ip[ip]["usuarios"].add(usuario)

    # Montar resultado final com apenas os IPs suspeitos
    resultado = {}

    for ip in falhas_por_ip:
        total = falhas_por_ip[ip]["tentativas"]

        # Aula 4 — só inclui IPs que atingiram o threshold
        if total >= threshold:
            # Aula 4 — classificar severidade com if/elif
            severidade = classificar_severidade(total, 20, 10, 5)

            resultado[ip] = {
                "tentativas": total,
                "usuarios": list(falhas_por_ip[ip]["usuarios"]),  # set -> lista para exibição
                "severidade": severidade
            }

    return resultado


# ─── Função 2: Detecção de Port Scan ─────────────────────────────────────────

def detectar_port_scan(eventos, threshold=3):
    """
    Conta portas únicas bloqueadas (BLOCK) por IP no firewall.
    Um mesmo IP tentando muitas portas diferentes indica um port scan.

    Retorna um dicionário no formato:
    { "185.220.101.1": {"portas": [21,22,23,...], "quantidade": 7, "severidade": "ALTA"} }
    """
    # Aula 7.3 — dicionário: chave=IP, valor=set de portas
    portas_por_ip = {}

    # Aula 6.3 — percorrer eventos com for
    for evento in eventos:
        if evento["fonte"] == "firewall" and evento["tipo"] == "BLOCK":
            ip = evento["ip"]
            porta = evento.get("porta", 0)

            if porta == 0:
                continue

            # Aula 7.3 + 7.5 — criar set de portas se IP ainda não existe
            if ip not in portas_por_ip:
                portas_por_ip[ip] = set()   # Aula 7.5 — set elimina duplicatas

            portas_por_ip[ip].add(porta)

    resultado = {}

    for ip in portas_por_ip:
        quantidade = len(portas_por_ip[ip])

        if quantidade >= threshold:
            severidade = classificar_severidade(quantidade, 10, 6, 3)

            resultado[ip] = {
                "portas": sorted(list(portas_por_ip[ip])),  # set -> lista ordenada
                "quantidade": quantidade,
                "severidade": severidade
            }

    return resultado


# ─── Função 3: Verificação de Blacklist ──────────────────────────────────────

def verificar_blacklist(eventos, blacklist=None):
    """
    Cruza os IPs presentes nos eventos com a blacklist de IPs maliciosos.
    Usa interseção de sets — operação O(n) eficiente.

    Retorna:
        ips_encontrados — set com IPs da blacklist detectados nos logs
        contagem_por_ip — dicionário {ip: total_de_eventos}
    """
    # Aula 4 — usar blacklist padrão se nenhuma for passada
    if blacklist is None:
        blacklist = BLACKLIST_PADRAO

    # Aula 7.5 — set comprehension para coletar todos os IPs dos eventos
    todos_ips = set()
    for evento in eventos:
        todos_ips.add(evento["ip"])

    # Aula 7.5 — interseção de sets: IPs que estão nos logs E na blacklist
    ips_encontrados = todos_ips & blacklist

    # Aula 7.3 — contar eventos por IP malicioso
    contagem_por_ip = {}
    for ip in ips_encontrados:
        total = 0
        for evento in eventos:
            if evento["ip"] == ip:
                total += 1
        contagem_por_ip[ip] = total

    return ips_encontrados, contagem_por_ip


# ─── Função 4: Resumo Consolidado de Ameaças ─────────────────────────────────

def gerar_resumo_ameacas(brute_force, port_scan, ips_blacklist):
    """
    Consolida as três detecções em uma lista única ordenada por perigo.
    IPs que aparecem em mais de uma detecção recebem pontuação mais alta.

    Retorna lista de dicionários ordenada do mais ao menos perigoso.
    """
    # Aula 7.5 — união dos sets para pegar todos os IPs suspeitos
    todos_ips = set()
    for ip in brute_force:
        todos_ips.add(ip)
    for ip in port_scan:
        todos_ips.add(ip)
    todos_ips = todos_ips | ips_blacklist   # Aula 7.5 — operador union

    # Aula 7.3 — dicionário para mapeamento de severidade -> pontuação
    peso = {"CRITICA": 4, "ALTA": 3, "MEDIA": 2, "BAIXA": 1}

    resumo = []

    # Aula 6.3 — percorrer todos os IPs suspeitos
    for ip in todos_ips:
        ameacas = []
        detalhes = {}
        pontuacao = 0

        # Aula 4 — checar em qual categoria cada IP aparece
        if ip in brute_force:
            ameacas.append("brute_force")
            detalhes["brute_force"] = brute_force[ip]
            pontuacao += peso.get(brute_force[ip]["severidade"], 0)

        if ip in port_scan:
            ameacas.append("port_scan")
            detalhes["port_scan"] = port_scan[ip]
            pontuacao += peso.get(port_scan[ip]["severidade"], 0)

        if ip in ips_blacklist:
            ameacas.append("blacklist")
            pontuacao += 4   # blacklist sempre soma o peso máximo

        # Aula 4 — classificar severidade final com if/elif
        if pontuacao >= 10:
            severidade_final = "CRITICA"
        elif pontuacao >= 6:
            severidade_final = "ALTA"
        elif pontuacao >= 3:
            severidade_final = "MEDIA"
        else:
            severidade_final = "BAIXA"

        resumo.append({
            "ip": ip,
            "ameacas": ameacas,
            "severidade": severidade_final,
            "pontuacao": pontuacao,
            "detalhes": detalhes
        })

    # Aula 7.1 — ordenar lista por pontuação (maior primeiro)
    resumo.sort(key=lambda x: x["pontuacao"], reverse=True)

    return resumo


# ─── Bloco de teste isolado ───────────────────────────────────────────────────
# Aula 11.5 — if __name__ == "__main__" para testar o módulo sozinho

if __name__ == "__main__":
    from coletor import carregar_todos_os_logs  # Aula 11.5 — importar módulo próprio

    print("=" * 55)
    print("  TESTE — detector.py")
    print("=" * 55)

    eventos = carregar_todos_os_logs("logs")

    print("\n[1] Deteccao de Brute Force (threshold=5)")
    print("-" * 55)
    bf = detectar_brute_force(eventos, threshold=5)
    for ip in bf:
        dados = bf[ip]
        print(f"  {ip:<22} {dados['tentativas']:>3} falhas  [{dados['severidade']}]")
        print(f"    Usuarios tentados: {dados['usuarios']}")

    print("\n[2] Deteccao de Port Scan (threshold=3)")
    print("-" * 55)
    ps = detectar_port_scan(eventos, threshold=3)
    for ip in ps:
        dados = ps[ip]
        print(f"  {ip:<22} {dados['quantidade']:>3} portas  [{dados['severidade']}]")
        print(f"    Portas: {dados['portas']}")

    print("\n[3] Verificacao de Blacklist")
    print("-" * 55)
    ips_bl, contagem = verificar_blacklist(eventos)
    print(f"  IPs maliciosos encontrados: {ips_bl}")
    for ip in contagem:
        print(f"  {ip:<22} {contagem[ip]:>3} eventos no total")

    print("\n[4] Resumo Consolidado (ordem de perigo)")
    print("-" * 55)
    resumo = gerar_resumo_ameacas(bf, ps, ips_bl)
    for entrada in resumo:
        print(f"  [{entrada['severidade']:<8}] {entrada['ip']:<22} pontuacao={entrada['pontuacao']}")
        print(f"    Ameacas: {entrada['ameacas']}")
