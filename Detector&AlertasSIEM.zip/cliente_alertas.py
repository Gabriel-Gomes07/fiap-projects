# cliente_alertas.py — Módulo 4 (Cliente): Console de Monitoramento
# SecuraPy SIEM
#
# Conceitos da apostila utilizados:
#   Aula 3  — variáveis, f-strings, input(), print()
#   Aula 4  — if/elif (verificar comandos digitados)
#   Aula 6  — while True (loop principal aguardando entrada do analista)
#   Aula 8  — try/except (tratar erros de conexão e desconexão)
#   Aula 13 — socket TCP, connect, send, recv, threading

import socket
import threading
import sys


# ─── Thread de recepção: fica ouvindo o servidor em segundo plano ─────────────

def receber_alertas(cliente):
    """
    Fica em loop recebendo mensagens do servidor e exibindo na tela.
    Roda em uma thread separada para não bloquear o input do analista.
    """
    # Aula 6.4 — while True: loop de recepção
    while True:
        # Aula 8 — try/except para tratar erros de rede
        try:
            dados = cliente.recv(4096)
        except (ConnectionResetError, OSError):
            print("\n[CLIENTE] Conexao perdida com o servidor.")
            break

        # recv() retorna vazio quando o servidor fecha a conexão
        if not dados:
            print("\n[CLIENTE] Servidor encerrou a conexao.")
            break

        # Aula 3 — decodificar bytes e exibir na tela
        mensagem = dados.decode("utf-8", errors="replace")
        print(mensagem, end="", flush=True)

    # Encerrar o programa quando o servidor cair
    sys.exit(0)


# ─── Conectar ao servidor e iniciar o console ────────────────────────────────

def conectar_servidor(host="127.0.0.1", porta=9999):
    """
    Conecta ao servidor de alertas e inicia o console interativo.

    O console funciona assim:
      - Uma thread separada recebe alertas do servidor em tempo real
      - O loop principal aguarda comandos digitados pelo analista
    """
    # Aula 13.2 — criar socket TCP
    cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Aula 8 — try/except para tratar falha de conexão
    try:
        cliente.connect((host, porta))
        print(f"[CLIENTE] Conectado ao SecuraPy SIEM ({host}:{porta})")

    except ConnectionRefusedError:
        print(f"[ERRO] Nao foi possivel conectar em {host}:{porta}")
        print("Verifique se o servidor esta rodando: python servidor_alertas.py")
        return

    except OSError as erro:
        print(f"[ERRO] Falha na conexao: {erro}")
        return

    # Aula 13.3 — criar thread para receber alertas em segundo plano
    thread_recepcao = threading.Thread(
        target=receber_alertas,
        args=(cliente,),
        daemon=True
    )
    thread_recepcao.start()

    # Aula 6.4 — while True: loop principal para enviar comandos
    try:
        while True:
            # Aula 8 — try/except para tratar Ctrl+C ou EOF
            try:
                comando = input("")
            except (EOFError, KeyboardInterrupt):
                break

            # Aula 4 — verificar se o usuário digitou algo
            if not comando.strip():
                continue

            # Aula 8 — try/except para tratar falha ao enviar
            try:
                cliente.sendall(comando.encode("utf-8"))
            except (BrokenPipeError, OSError):
                print("[CLIENTE] Conexao perdida.")
                break

            # Aula 4 — encerrar loop se o comando for /sair
            if comando.strip().lower() == "/sair":
                break

    except KeyboardInterrupt:
        print("\n[CLIENTE] Encerrando console...")

    finally:
        # Aula 8 — fechar socket com try/except
        try:
            cliente.close()
        except OSError:
            pass
        print("[CLIENTE] Desconectado.")


# Aula 11.5 — ponto de entrada do módulo
if __name__ == "__main__":
    # Aula 11 — sys.argv para aceitar host e porta como argumentos
    # Uso: python cliente_alertas.py             (localhost padrão)
    #      python cliente_alertas.py 192.168.1.5 9999
    if len(sys.argv) > 1:
        host = sys.argv[1]
    else:
        host = "127.0.0.1"

    if len(sys.argv) > 2:
        # Aula 8 — try/except para tratar porta inválida
        try:
            porta = int(sys.argv[2])
        except ValueError:
            print("[ERRO] Porta invalida. Usando porta 9999.")
            porta = 9999
    else:
        porta = 9999

    conectar_servidor(host, porta)
